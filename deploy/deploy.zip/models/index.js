const invoiceModel = require('./invoiceModel')
const notificationModel = require('./notification')

module.exports = {
  invoiceModel,
  notificationModel
}